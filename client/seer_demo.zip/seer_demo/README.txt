In this folder run:

python3 -m http.server

Then go to:

http://localhost:8000/